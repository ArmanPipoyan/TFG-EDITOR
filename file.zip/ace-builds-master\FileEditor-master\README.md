# FileEditor
Simple code editor with PHP

## Important
This code has no security. Putting this on a public network means that anybody could access to your files and be able to edit them or even create malicious files on your computer/server. **Use at your own risk.** If you want to make this content secure add a login system and ensure that users are logged in before running any potentially risky php (making files, editing, saving...).
